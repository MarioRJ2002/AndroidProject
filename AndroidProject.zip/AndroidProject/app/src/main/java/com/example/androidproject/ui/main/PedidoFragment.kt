package com.example.androidproject.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import com.example.androidproject.databinding.PedidoFragmentBinding

class PedidoFragment : Fragment() {

    private lateinit var viewModel: PedidoViewModel

    companion object {
        fun newInstance() = PedidoFragment()

    }

    override fun onCreateView(

        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = PedidoFragmentBinding.inflate(inflater)
        var Camarero = ""
        var precioTotal = 0.00

        binding.button2.setOnClickListener {
            if (viewModel.getCroquetas().toInt() == 0) {

            } else {
                viewModel.croquetaMenos()
                binding.textView3.setText(viewModel.getCroquetas())
            }
        }

        binding.button3.setOnClickListener{
            viewModel.croquetaMas()
            binding.textView3.setText(viewModel.getCroquetas())
        }

        binding.button4.setOnClickListener {
            if (viewModel.getMontaditos().toInt() == 0) {
            } else {
                viewModel.montaditoMenos()
                binding.textView6.setText(viewModel.getMontaditos())
            }
        }

        binding.button5.setOnClickListener{
            viewModel.montaditoMas()
            binding.textView6.setText(viewModel.getMontaditos())
        }

        binding.button6.setOnClickListener {
            if (viewModel.getaprobados().toInt() == 0) {
            } else {
                viewModel.aprobadoMenos()
                binding.textView9.setText(viewModel.getaprobados())
            }
        }

        binding.button7.setOnClickListener{
            viewModel.aprobadoMas()
            binding.textView9.setText(viewModel.getaprobados())
        }

        binding.button.setOnClickListener {
            precioTotal = viewModel.calcularPrecios()
            Camarero = "Le atenderá en su pedido: "+viewModel.property.value?.name
            Navigation.findNavController(view).navigate(R.id.)
        }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(PedidoViewModel::class.java)

    }

}