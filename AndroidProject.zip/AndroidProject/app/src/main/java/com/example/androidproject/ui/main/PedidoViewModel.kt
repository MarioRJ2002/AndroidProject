package com.example.androidproject.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PedidoViewModel : ViewModel() {

    private val _status = MutableLiveData<String>()

    val status: LiveData<String>
        get() = _status

   init {
       _status.value = ""
       getUsersProperties()
    }

    private val _property = MutableLiveData<ObjetoRetrofit>()

    val property: LiveData<ObjetoRetrofit>
        get() = _property

    private fun getUsersProperties() {
        viewModelScope.launch {
            try {
                var listResult = Api.retrofitService.getProperties()
                _status.value = "Success: ${listResult.size} Mars properties retrieved"
                if (listResult.size > 0) {
                    _property.value = listResult[0]
                }
            } catch (e: Exception) {
                _status.value = "Failure: ${e.message}"
            }

        }
    }

    private val _numProductos = mutableMapOf(
        Pair("croquetas de jamon", 0),
        Pair("Montaditos de filete", 0),
        Pair("Un aprobado en android", 0)
    )
    private val _precioProductos = mapOf<String,Double>(
        Pair("croquetas de jamon", 2.95),
        Pair("Montaditos de filete", 1.95),
        Pair("Un aprobado en android",5.00)
    )

    fun croquetaMas() {
        val base = _numProductos["croquetas de jamon"]
        if (base != null) {
            _numProductos["croquetas de jamon"] = base + 1
        }
    }

    fun croquetaMenos() {
        val base = _numProductos["croquetas de jamon"]
        if (base != null) {
            _numProductos["croquetas de jamon"] = base - 1
        }
    }

    fun getCroquetas(): String {
        return _numProductos["croquetas de jamon"].toString()
    }

    fun montaditoMas() {
        val base = _numProductos["Montaditos de filete"]
        if (base != null) {
            _numProductos["Montaditos de filete"] = base + 1
        }
    }

    fun montaditoMenos() {
        val base = _numProductos["Montaditos de filete"]
        if (base != null) {
            _numProductos["Montaditos de filete"] = base - 1
        }
    }

    fun getMontaditos(): String {
        return _numProductos["Montaditos de filete"].toString()
    }

    fun aprobadoMas() {
        val base = _numProductos["Un aprobado en android"]
        if (base != null) {
            _numProductos["Un aprobado en android"] = base + 1
        }
    }

    fun aprobadoMenos() {
        val base = _numProductos["Un aprobado en android"]
        if (base != null) {
            _numProductos["Un aprobado en android"] = base - 1
        }
    }

    fun getaprobados(): String {
        return _numProductos["Un aprobado en android"].toString()
    }

    fun calcularPrecios(): Double{
        var precioTotal = 0.00
        _numProductos.forEach{
            precioTotal+= (_precioProductos[it.key]!!*it.value)
        }
        return precioTotal
    }
}
